$(function() {
    //cache the window object

    var $window = $(window);

    //Parallax background effect

    $('section[data-type="background"]').each(function() {
        var $bgobj = $(this); //assigning object
    
    	$(window).scroll(function(){
    		//Scroll the background at var speed
    		// the y position negative vbecause we r scrollin up

    		var yPos = -($window.scrollTop()/$bgobj.data('speed'));

    		//put together our final position
    		var coords = '70% ' + yPos + 'px';

    		//move the background

    		$bgobj.css({ backgroundPosition: coords });


    	}); // end of windows scroll
    });


});